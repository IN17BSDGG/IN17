﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Parser_SQL_Hamburg_aus_CSV
{
    public partial class form_CSVParser : Form
    {
        OpenFileDialog file;

        public form_CSVParser()
        {
            InitializeComponent();
            file = new OpenFileDialog();
            file.Filter = "CSV|*.csv";
            //box_pfad.Text = file.ToString();
        }
        private void btn_change_file_Click(object sender, EventArgs e)
        {
            if (file.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                box_pfad.Text = file.FileName;
            }
            else
            {
                return;
            }
        }

        private void btn_auslesen_Click(object sender, EventArgs e)
        {

            pBar1.Minimum = 1;
            // Set the initial value of the ProgressBar.
            pBar1.Value = 1;
            // Set the Step property to a value of 1 to represent each file being copied.
            pBar1.Step = 1;

            StreamReader reader = new StreamReader(File.OpenRead(file.FileName));
            //StreamReader reader = new StreamReader(File.OpenRead("C:\\Users\\klietzm\\Desktop\\bremen.csv"));
            var lineCount = File.ReadAllLines(@"" + file.FileName).Length;
            List<string> Spalte1 = new List<String>();

            pBar1.Maximum = lineCount;

            int counter = 0;
            string line;

            Spalte1.Add("id (int),jahr (FK),monat (FK),landkreis (FK),ankuenfte,uebernachtungen\r\n");

            bool endFound = false;

            int lines = 0;

            while ((line = reader.ReadLine()) != null)
            {
                pBar1.PerformStep();
                if (counter < 4)
                {

                }
                else
                {
                    string TempLine = line;
                    TempLine = TempLine.Replace("Hotels, Hotels garnis, Gasth�fe, Pensionen;", "");
                    TempLine = TempLine.Replace("Hotels, Hotels garnis, Gasth?fe, Pensionen", "");
                    TempLine = TempLine.Replace("Stadt Bremen;", "");
                    TempLine = TempLine.Replace("Stadt Bremerhaven;", "");
                    TempLine = TempLine.Replace("Sonstige Einrichtungen 3);", "");
                    TempLine = TempLine.Replace("Insgesamt;", "");
                    TempLine = TempLine.Replace("-", ",");
                    TempLine = TempLine.Replace(";", ",");
                    TempLine = TempLine.Replace(",,", ",");

                    if (TempLine == "")
                    {
                        endFound = true;
                    }

                    string[] words = TempLine.Split(',');

                    string newLine;


                    if (words.Length >= 5 && words[0] != "" && words[0] != "" && words[1] != "" && words[1] != "" && words[2] != "" && words[2] != "" && words[3] != "" && words[3] != "" && words[4] != "" && words[4] != "" && !endFound)
                    {
                        //entfernen der 0 im monat
                        if (words[2].StartsWith("0"))
                        {
                            words[2] = words[2].Substring(1);
                        }

                        //entfernen der 2 ersten jahres zahlen
                        words[1] = words[1].Substring(2);
                        //          ID             Jahr            Monat            Landkreis      üebernachtungen   ankuenfte
                        newLine = (++lines).ToString() + "," + words[1] + "," + words[2] + "," + words[0] + "," + words[4] + "," + words[3];

                        Spalte1.Add(newLine + "\r\n");
                    }
                }
                
                counter++;
            }

            
            

            string ausgabepfad = Environment.GetFolderPath(Environment.SpecialFolder.Desktop).ToString();
            string ausgabestring = String.Join("", Spalte1.ToArray());
            System.IO.File.WriteAllText(ausgabepfad+"/ausgabe.txt", ausgabestring);

            reader.Close();


            string message = "Soll das Programm beendet werden?";
            string caption = "Fertig";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;

            result = MessageBox.Show(message, caption, buttons);

            if (result == System.Windows.Forms.DialogResult.Yes)
            {

                // Closes the parent form.

                this.Close();

            }
        }
    }
}
