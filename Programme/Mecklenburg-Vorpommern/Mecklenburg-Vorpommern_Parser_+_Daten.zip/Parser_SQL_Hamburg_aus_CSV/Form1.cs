﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using ExcelDataReader;

namespace Parser_SQL_Schleswig_Hollstein
{
    public partial class form_shparser : Form
    {
        FolderBrowserDialog ordner;

        public form_shparser()
        {
            InitializeComponent();
            ordner = new FolderBrowserDialog();
            box_pfad.Text = ordner.ToString();
        }
        private void btn_change_folder_Click(object sender, EventArgs e)
        {
            DialogResult result = ordner.ShowDialog();

            if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(ordner.SelectedPath))
            {
                box_pfad.Text = ordner.SelectedPath.ToString();
            }
            else
            {
                return;
            }
        }

        private void btn_auslesen_Click(object sender, EventArgs e)
        {
            string jahr = "";
            string monat = "";

            string ausgabe = "jahr (FK),monat (FK),landkreis (FK),ankuenfte,uebernachtungen" + Environment.NewLine;
            string fehler = "";

            string[] ordner_im_ordner = Directory.GetDirectories(ordner.SelectedPath.ToString());
            foreach (string unterordner in ordner_im_ordner)
            {
                jahr = unterordner.Substring(Math.Max(0, unterordner.Length - 4));

                string[] dateien_im_ordner = Directory.GetFiles(unterordner);

                foreach (string datei in dateien_im_ordner)
                {
                    bool isHidden = (File.GetAttributes(datei) & FileAttributes.Hidden) == FileAttributes.Hidden;
                    if (!isHidden)
                    {
                        monat = "" + datei.Substring(datei.Length - 6,2);
                        
                        if (Int32.Parse(jahr) < 2017 && Int32.Parse(jahr) > 2013)
                        {
                            using (var stream = File.Open(datei, FileMode.Open, FileAccess.Read))
                            {
                                using (var reader = ExcelReaderFactory.CreateReader(stream))
                                {
                                    var result = reader.AsDataSet();

                                    DataTable Tabelle_die_gesucht_wird = result.Tables[7];

                                    foreach (DataRow row in Tabelle_die_gesucht_wird.AsEnumerable())
                                    {
                                        var zelle = row.ItemArray[1].ToString();
                                        
                                            if (zelle.Length > 0)
                                            {
                                                var ankuenfte = row.ItemArray[2].ToString();
                                                var uebernachtungen = row.ItemArray[4].ToString();

                                                if (zelle.ToString().Contains("Rostock, Hansestadt"))
                                                {
                                                    string rs = "13003";
                                                    string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                    }
                                                }

                                                if (zelle.ToString().Contains("Schwerin, Landeshauptstadt"))
                                                {
                                                    string rs = "13004";
                                                    string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                    }
                                                }

                                                if (zelle.ToString().Contains("Seenplatte"))
                                                {
                                                    string rs = "13071";
                                                    string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                    }
                                                }

                                                if (zelle.ToString().Contains("Landkreis Rostock"))
                                                {
                                                    string rs = "13072";
                                                    string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                    }
                                                }

                                                if (zelle.ToString().Contains("Vorpommern-R"))
                                                {
                                                    string rs = "13073";
                                                    string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                    }
                                                }

                                                if (zelle.ToString().Contains("Nordwestmecklenburg"))
                                                {
                                                    string rs = "13074";
                                                    string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                    }
                                                }

                                                if (zelle.ToString().Contains("Vorpommern-Greifswald"))
                                                {
                                                    string rs = "13075";
                                                    string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                    }
                                                }

                                                if (zelle.ToString().Contains("Ludwigslust-Parchim"))
                                                {
                                                    string rs = "13076";
                                                    string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                    }
                                                }
                                            }
                                    }
                                }
                            }
                        }
                        else if(Int32.Parse(jahr) > 2016)
                        {
                            using (var stream = File.Open(datei, FileMode.Open, FileAccess.Read))
                            {
                                using (var reader = ExcelReaderFactory.CreateReader(stream))
                                {
                                    var result = reader.AsDataSet();

                                    DataTable Tabelle_die_gesucht_wird = result.Tables[6];

                                    foreach (DataRow row in Tabelle_die_gesucht_wird.AsEnumerable())
                                    {
                                        var zelle = row.ItemArray[1].ToString();

                                        if (true)
                                        {
                                            if (zelle.Length > 0)
                                            {
                                                var ankuenfte = row.ItemArray[2].ToString();
                                                var uebernachtungen = row.ItemArray[4].ToString();

                                                if (zelle.ToString().Contains("Rostock, Hansestadt"))
                                                {
                                                    string rs = "13003";
                                                    string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                    }
                                                }

                                                if (zelle.ToString().Contains("Schwerin, Landeshauptstadt"))
                                                {
                                                    string rs = "13004";
                                                    string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                    }
                                                }

                                                if (zelle.ToString().Contains("Seenplatte"))
                                                {
                                                    string rs = "13071";
                                                    string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                    }
                                                }

                                                if (zelle.ToString().Contains("Landkreis Rostock"))
                                                {
                                                    string rs = "13072";
                                                    string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                    }
                                                }

                                                if (zelle.ToString().Contains("Vorpommern-R"))
                                                {
                                                    string rs = "13073";
                                                    string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                    }
                                                }

                                                if (zelle.ToString().Contains("Nordwestmecklenburg"))
                                                {
                                                    string rs = "13074";
                                                    string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                    }
                                                }

                                                if (zelle.ToString().Contains("Vorpommern-Greifswald"))
                                                {
                                                    string rs = "13075";
                                                    string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                    }
                                                }

                                                if (zelle.ToString().Contains("Ludwigslust-Parchim"))
                                                {
                                                    string rs = "13076";
                                                    string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            using (var stream = File.Open(datei, FileMode.Open, FileAccess.Read))
                            {
                                using (var reader = ExcelReaderFactory.CreateReader(stream))
                                {
                                    var result = reader.AsDataSet();

                                    DataTable Tabelle_die_gesucht_wird = result.Tables[7];

                                    foreach (DataRow row in Tabelle_die_gesucht_wird.AsEnumerable())
                                    {
                                        var zelle = row.ItemArray[0].ToString();

                                        if (zelle.Length > 0)
                                        {
                                            var ankuenfte = row.ItemArray[1].ToString();
                                            var uebernachtungen = row.ItemArray[3].ToString();

                                            if (zelle.ToString().Contains("Rostock, Hansestadt") && !zelle.ToString().Contains(")"))
                                            {
                                                string rs = "13003";
                                                string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                ausgabe = ausgabe + zeile + Environment.NewLine;
                                                if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                {
                                                    fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                }
                                            }

                                            if (zelle.ToString().Contains("Landeshauptstadt") && !zelle.ToString().Contains(")"))
                                            {
                                                string rs = "13004";
                                                string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                ausgabe = ausgabe + zeile + Environment.NewLine;
                                                if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                {
                                                    fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                }
                                            }

                                            if (zelle.ToString().Contains("Seenplatte") && !zelle.ToString().Contains(")"))
                                            {
                                                string rs = "13071";
                                                string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                ausgabe = ausgabe + zeile + Environment.NewLine;
                                                if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                {
                                                    fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                }
                                            }

                                            if (zelle.ToString().Contains("Landkreis Rostock") && !zelle.ToString().Contains(")"))
                                            {
                                                string rs = "13072";
                                                string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                ausgabe = ausgabe + zeile + Environment.NewLine;
                                                if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                {
                                                    fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                }
                                            }

                                            if (zelle.ToString().Contains("Vorpommern-R") && !zelle.ToString().Contains(")"))
                                            {
                                                string rs = "13073";
                                                string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                ausgabe = ausgabe + zeile + Environment.NewLine;
                                                if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                {
                                                    fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                }
                                            }

                                            if (zelle.ToString().Contains("Nordwestmecklenburg") && !zelle.ToString().Contains(")"))
                                            {
                                                string rs = "13074";
                                                string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                ausgabe = ausgabe + zeile + Environment.NewLine;
                                                if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                {
                                                    fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                }
                                            }

                                            if (zelle.ToString().Contains("Vorpommern-Greifswald") && !zelle.ToString().Contains(")"))
                                            {
                                                string rs = "13075";
                                                string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                ausgabe = ausgabe + zeile + Environment.NewLine;
                                                if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                {
                                                    fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                }
                                            }

                                            if (zelle.ToString().Contains("Ludwigslust-Parchim") && !zelle.ToString().Contains(")"))
                                            {
                                                string rs = "13076";
                                                string zeile = jahr + "," + monat + "," + rs + "," + ankuenfte + "," + uebernachtungen;
                                                ausgabe = ausgabe + zeile + Environment.NewLine;
                                                if (Int64.Parse(ankuenfte) < 1800 || Int64.Parse(uebernachtungen) < 1800)
                                                {
                                                    fehler = fehler + jahr + " " + monat + rs + Environment.NewLine;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            System.IO.Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.Desktop).ToString());
            string ausgabepfad = Environment.GetFolderPath(Environment.SpecialFolder.Desktop).ToString();
            string ausgabestring = ausgabe.TrimEnd(Environment.NewLine.ToCharArray());
            string ausgabetag = DateTime.Now.ToString("dd");
            string ausgabemonat = DateTime.Now.ToString("MM");
            string ausgabejahr = DateTime.Now.ToString("yyyy");
            System.IO.File.WriteAllText(ausgabepfad + "/" + ausgabejahr + "-" + ausgabemonat + "-" + ausgabetag + "_ausgabe_MVP.csv", ausgabestring);

            if (ausgabestring.Split('\n').Length != 8 * 6 * 12 + 8 * 8 + 1 )
            {
                fehler = fehler + "Eine Datei wurde nicht gelesen";
            }

            if (fehler != "")
            {
                System.IO.File.WriteAllText(Environment.GetFolderPath(Environment.SpecialFolder.Desktop).ToString() + "/Fehler.txt", fehler);
            }
            MessageBox.Show("Fertig!");
        }        
    }
}