﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using ExcelDataReader;

namespace Parser_SQL_Schleswig_Hollstein
{
    public partial class form_shparser : Form
    {
        OpenFileDialog datei;

        public form_shparser()
        {
            InitializeComponent();
            datei = new OpenFileDialog();
            box_pfad.Text = datei.ToString();
        }
        private void btn_change_file_Click(object sender, EventArgs e)
        {
            if (datei.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                box_pfad.Text = datei.FileName;
            }
            else
            {
                return;
            }
        }

        private void btn_auslesen_Click(object sender, EventArgs e)
        {
            /*StreamReader reader = new StreamReader(File.OpenRead(file.FileName));

            List<string> Spalte1 = new List<String>();

            string line = reader.ReadToEnd();
            Spalte1.Add(line);

            string ausgabepfad = Environment.GetFolderPath(Environment.SpecialFolder.Desktop).ToString();
            string ausgabestring = String.Join(",", Spalte1.ToArray());
            System.IO.File.WriteAllText(ausgabepfad+"/ausgabe.txt", ausgabestring);

            reader.Close();
            */

            string ausgabe = "";
            string jahr = "";
            string monat = "";

            using (var stream = File.Open(datei.FileName, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet();

                    int i = 0;
                    foreach (DataRow row in result.Tables[3].AsEnumerable())
                    {
                        i++;
                        if (i>=8)
                        {
                            string testwert = row.ItemArray[0].ToString();

                            if (testwert.Length > 0)
                            {
                                if (Char.IsDigit(testwert[0]) && Char.IsDigit(testwert[1]) && !Char.IsDigit(testwert[4]))
                                {
                                    string dateiname = datei.FileName.ToString().Split('\\').Last().Substring(8,4);
                                    jahr = "20" + dateiname.Substring(0,2);
                                    monat = dateiname.Substring(2,2);
                                    string zeile = jahr + "," + monat + "," + "010" + row.ItemArray[0].ToString()[0]+row.ItemArray[0].ToString()[1] + "," + row.ItemArray[1].ToString() + "," + row.ItemArray[3].ToString();
                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                }
                            }
                        }
                    }
                }
            }

            string ausgabepfad = Environment.GetFolderPath(Environment.SpecialFolder.Desktop).ToString();
            string ausgabestring = ausgabe;
            System.IO.File.WriteAllText(ausgabepfad + "/" + jahr + "_" + monat + ".txt", ausgabestring);
        }
    }
}
