﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using ExcelDataReader;

namespace Parser_SQL_Schleswig_Hollstein
{
    public partial class form_shparser : Form
    {
        FolderBrowserDialog ordner;

        public form_shparser()
        {
            InitializeComponent();
            ordner = new FolderBrowserDialog();
            box_pfad.Text = ordner.ToString();
        }
        private void btn_change_folder_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ausschließlich den Ordner wählen, in dem die Unterordner der Jahre liegen! \n\n Außerdem die Geöffneten Excel-Dateien schließen.");
            DialogResult result = ordner.ShowDialog();

            if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(ordner.SelectedPath))
            {
                box_pfad.Text = ordner.SelectedPath.ToString();
            }
            else
            {
                return;
            }
        }

        private void btn_auslesen_Click(object sender, EventArgs e)
        {
            string jahr = "";
            string monat = "";

            string ausgabe = "jahr (FK),monat (FK),landkreis (FK),ankuenfte,uebernachtungen" + Environment.NewLine;
            string fehler = "";

            string[] ordner_im_ordner = Directory.GetDirectories(ordner.SelectedPath.ToString());
            foreach (string unterordner in ordner_im_ordner)
            {
                jahr = unterordner.Substring(Math.Max(0, unterordner.Length - 4));

                string[] dateien_im_ordner = Directory.GetFiles(unterordner);

                foreach (string datei in dateien_im_ordner)
                {
                    bool isHidden = (File.GetAttributes(datei) & FileAttributes.Hidden) == FileAttributes.Hidden;
                    if (!isHidden)
                    {
                        for (int k = 0; k < datei.Length; k++)
                        {
                            if (Char.IsDigit(datei[k]) && !Char.IsDigit(datei[k + 1]) && Char.IsDigit(datei[k - 1]))
                            {
                                monat = "" + datei[k - 1] + datei[k];
                            }
                        }

                        if (Int32.Parse(jahr) > 2012)
                        {
                            using (var stream = File.Open(datei, FileMode.Open, FileAccess.Read))
                            {
                                using (var reader = ExcelReaderFactory.CreateReader(stream))
                                {
                                    var result = reader.AsDataSet();

                                    DataTable Tabelle_die_gesucht_wird = new DataTable();
                                    bool abbruch = false;

                                    foreach (DataTable table in result.Tables)
                                    {
                                        if (table.Rows.Count > 0)
                                        {
                                            if (!abbruch && table.Rows[0].ItemArray[0].ToString().Contains("Ankünfte, Übernachtungen und Aufenthaltsdauer der Gäste in Beherbergungsstätten"))
                                            {
                                                Tabelle_die_gesucht_wird = table;
                                                abbruch = true;
                                            }
                                        }
                                    }

                                    foreach (DataRow row in Tabelle_die_gesucht_wird.AsEnumerable())
                                    {
                                        var zelle1 = row.ItemArray[0].ToString();

                                        if (zelle1.Length > 0)
                                        {
                                            if (Char.IsDigit(zelle1[0]) && Char.IsDigit(zelle1[1]) && !Char.IsDigit(zelle1[4]))
                                            {
                                                if ((jahr == "2015" && monat == "04") || (jahr == "2016" && monat == "10"))
                                                {
                                                    string zeile = jahr + "," + monat + "," + "010" + zelle1[0] + zelle1[1] + "," + row.ItemArray[3].ToString() + "," + row.ItemArray[5].ToString();
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(row.ItemArray[3].ToString()) < 1800 || Int64.Parse(row.ItemArray[5].ToString()) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + Environment.NewLine;
                                                    }
                                                }
                                                else
                                                {
                                                    string zeile = jahr + "," + monat + "," + "010" + zelle1[0] + zelle1[1] + "," + row.ItemArray[1].ToString() + "," + row.ItemArray[3].ToString();
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int64.Parse(row.ItemArray[1].ToString()) < 1800 || Int64.Parse(row.ItemArray[3].ToString()) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + Environment.NewLine;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            using (var stream = File.Open(datei, FileMode.Open, FileAccess.Read))
                            {
                                using (var reader = ExcelReaderFactory.CreateReader(stream))
                                {
                                    var result = reader.AsDataSet();

                                    List<DataTable> Tabellen_die_gesucht_werden = new List<DataTable>();

                                    foreach (DataTable table in result.Tables)
                                    {
                                        if (table.Rows.Count > 0)
                                        {
                                            if (table.Rows[2].ItemArray[0].ToString().Contains("Ankünfte, Übernachtungen und Aufenthaltsdauer der Gäste in Beherbergungsstätten"))
                                            {
                                                Tabellen_die_gesucht_werden.Add(table);
                                            }
                                        }
                                    }
                                    foreach (DataTable gefilterte_tabellen in Tabellen_die_gesucht_werden)
                                    {
                                        for (int i = 0; i < gefilterte_tabellen.Rows.Count; i++)
                                        {
                                            var zelle1 = gefilterte_tabellen.Rows[i].ItemArray[0].ToString();

                                            if (zelle1.Length > 0)
                                            {
                                                string vergleichsstring = gefilterte_tabellen.Rows[Math.Max(0, i - 2)].ItemArray[0].ToString();

                                                if (zelle1[0].ToString() == "0" && zelle1[1].ToString() == "0" && (zelle1[2].ToString() == "1" || zelle1[2].ToString() == "2" || zelle1[2].ToString() == "4"))
                                                {
                                                    string zeile = jahr + "," + monat + "," + "010" + zelle1[1] + zelle1[2] + "," + gefilterte_tabellen.Rows[i].ItemArray[1].ToString() + "," + gefilterte_tabellen.Rows[i].ItemArray[3].ToString();
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int32.Parse(gefilterte_tabellen.Rows[i].ItemArray[1].ToString()) < 1800 || Int32.Parse(gefilterte_tabellen.Rows[i].ItemArray[3].ToString()) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + Environment.NewLine;
                                                    }
                                                }
                                                else if (zelle1.Contains("Zusammen") && Char.IsDigit(vergleichsstring[0]))
                                                {
                                                    string zeile = jahr + "," + monat + "," + "010" + vergleichsstring[1] + vergleichsstring[2] + "," + gefilterte_tabellen.Rows[i].ItemArray[1].ToString() + "," + gefilterte_tabellen.Rows[i].ItemArray[3].ToString();
                                                    ausgabe = ausgabe + zeile + Environment.NewLine;
                                                    if (Int32.Parse(gefilterte_tabellen.Rows[i].ItemArray[1].ToString()) < 1800 || Int32.Parse(gefilterte_tabellen.Rows[i].ItemArray[3].ToString()) < 1800)
                                                    {
                                                        fehler = fehler + jahr + " " + monat + Environment.NewLine;
                                                    }
                                                }
                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            System.IO.Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.Desktop).ToString());
            string ausgabepfad = Environment.GetFolderPath(Environment.SpecialFolder.Desktop).ToString();
            string ausgabestring = ausgabe.TrimEnd(Environment.NewLine.ToCharArray());
            string ausgabetag = DateTime.Now.ToString("dd");
            string ausgabemonat = DateTime.Now.ToString("MM");
            string ausgabejahr = DateTime.Now.ToString("yyyy");
            System.IO.File.WriteAllText(ausgabepfad + "/" + ausgabejahr + "-" + ausgabemonat + "-" + ausgabetag + "_ausgabe_SH.csv", ausgabestring);
            if (fehler != "")
            {
                System.IO.File.WriteAllText(Environment.GetFolderPath(Environment.SpecialFolder.Desktop).ToString() + "/Fehler.txt", fehler);
            }
            MessageBox.Show("Fertig!");
        }        
    }
}